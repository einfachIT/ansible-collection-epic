![molecule_test](https://github.com/Bassinator/ansible-role-ssh-tor/actions/workflows/blank.yml/badge.svg)
# ansible-role-ssh-tor


## prerequisites
The following packates need to be installed
- python3
- python3-dev
- virtualenv
